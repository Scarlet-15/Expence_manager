from tkinter import *
r = Tk()
r.geometry("1100x800")
r.title(' MY WALLET ')
r.config(bg='white')
canvas1 = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")               #creation of the heading canvas
canvas1.pack()
labelfont=('times',30,'italic')
    
a=Label(r,text=' MY WALLET ',fg='white',bg='deepskyblue3',font=labelfont)    
canvas1.create_window(550, 50, window=a)                                         #adding the heading label to the canvas
canvas1 = Canvas(r, width = 4000, height = 30,bg="deepskyblue3")               #creation of the heading canvas
canvas1.pack()
b=Label(r,text='Lets manage your money together',fg='white',bg='deepskyblue3',font=('italic'))
canvas1.create_window(550,15, window=b)                                          #adding the heading label to the canvas
    
canvas1 = Canvas(r, width = 4000, height = 800,bg="white")                 #creation of the subheading canvas
canvas1.pack()
labelfont=('times',30,'italic')
a=Label(r,text='INFO',fg='white',bg='deepskyblue3',font=labelfont)
canvas1.create_window(550,40, window=a)
b=Label(r,text='What Is Considered to Be a Living Expense?',bg="white",font=labelfont)
canvas1.create_window(600,100, window=b)


labelfont=('times',13,'bold','underline')
c=Label(r,text='Loan: \nWhen money is given to another party in exchange for repayment of the loan\n principal amount plus interest',fg='black',bg='lightgrey',font=labelfont)
canvas1.create_window(750,150, window=c)
lfont=('times',10,'italic')
d=Label(r,text='•Gold loan \n •Housing loan \n •Education loan \n •Personal Loan',fg='black',bg='white',font=lfont)
canvas1.create_window(650,220, window=d)
lablefont=('times',13,'bold','underline')
e=Label(r,text='Tax:\n A compulsory contribution to state revenue, levied by the government on\n workers income.',fg='black',bg='lightgrey',font=lablefont)
canvas1.create_window(750,290, window=e)
lfont=('times',10,'italic')
f=Label(r,text='•Income tax \n •Property tax \n •Water tax \n • Health tax',fg='black',bg='white',font=lfont)
canvas1.create_window(650,370, window=f)

button=Button(r,text='←[2]',activeforeground='blue',width=5,height=1,fg='white',bg="deepskyblue3")
canvas1.create_window(550,450, window=button)


photo = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\catogory.png")
canvas1.create_image(200,250, image=photo)

mainloop() 
