from mysql import connector
mycon=connector.connect(port="3308",user="root",password="",database= "expencemanager")
cursor=mycon.cursor()
cursor.execute("create table expence(AMOUNT int,USEDFOR varchar(25),DATE date,DESCRIPTION varchar(100),\
                  MODEOFTRANSACTION varchar(15),BILL varchar(200),CATOGORY varchar(25),email varchar(25))")
cursor.execute("create table userinfo(fname varchar(25),lname varchar(25),profes varchar(25),email varchar(25) ,\
                            phone char(10),password char(13))")
cursor.execute("create table budget(email varchar(25),income int,ibudget int,date date,bcross int)")
