from tkinter import *
from PIL import ImageTk,Image
from mysql import connector 
from tkinter import messagebox
from datetime import datetime
from tkinter import filedialog
from functools import partial
from tabulate import tabulate
import matplotlib.pyplot
r=Tk()
cou=0
try:
    con = connector.connect(port="3308",user="root",password="",database="expencemanager")
    custor=con.cursor()
except:
    messagebox.showwarning("ERROR","Please turn on your WampServer....!!")
    cou+=1
    





def expinfo(r,a):
    infor=a
    print(infor)
    
        
    r.destroy()
    cursor=con.cursor()
    cursor.execute("use expencemanager")
    global photo,value,info,icon,budget
    value=""
    r =Toplevel()
    if infor==3:
        homepg(r)
        return
    
    cudate=StringVar()
    
    curdate=""
    r.geometry("1100x700")
    r.title('₹ MY WALLET ₹')
    r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
    r.config(bg='white')
    
    urdate=str(datetime.date(datetime.now()))
    rdate=urdate.split('-')
    for a in range(len(rdate)-1,-1,-1):
        curdate+=(rdate[a]+".")
    print(curdate)
    curdate=curdate[:len(curdate)-1]
    canvas1 = Canvas(r, width = 4000, height = 90,bg="deepskyblue3")
    canvas1.pack()
        
    labelfont=('times',30,'italic')
    icon = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
    p=Label(r,image=icon,bg="deepskyblue3")
    canvas1.create_window(100, 50, window=p) 
    a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)
    canvas1.create_window(550, 50, window=a)

    canvas2 = Canvas(r, width = 4000, height = 40,bg="deepskyblue2")
    canvas2.pack()
    labelfont1=('aerial',15,'italic')
    b=Label(r,text='$ Lets manage your money together $',fg='white',bg='deepskyblue2',font=labelfont1)
    canvas2.create_window(550,25, window=b)   
    canvas1 = Canvas(r, width = 4000, height = 30,bg="deepskyblue")
    canvas1.pack()
    if infor==1:    
        c=Label(r,text='ADD EXPENSES',fg='white',bg='deepskyblue',font=('bold'))
        canvas1.create_window(550,15, window=c)
        d=Button(r,text="<<Back",bg="deepskyblue3",command=lambda:homepg(r),fg="white")
        canvas1.create_window(30,17, window=d)
    else:
        c=Label(r,text='EDIT',fg='white',bg='deepskyblue',font=('bold'))
        canvas1.create_window(550,15, window=c)
        d=Button(r,text="<<Back",bg="deepskyblue3",command=lambda:alltrans1(r),fg="white")
        canvas1.create_window(30,17, window=d)
    
    
        
    canvas2 = Canvas(r, width = 500, height = 600,bg="skyblue")
    canvas2.pack()
        
    lfont=('aerial',10,'bold')
    f=Label(r,text='PAID FOR',font=lfont)
    canvas2.create_window(77,50, window=f)
    e=Label(r,text='AMOUNT',font=lfont)
    canvas2.create_window(74,100, window=e)

    g=Label(r,text='DATE(DD.MM.YYYY)',font=lfont)
    canvas2.create_window(107,150, window=g)
    h=Label(r,text='DESCRIPTION (optional)',font=lfont)
    canvas2.create_window(120,200, window=h)
    i=Label(r,text='MODE OF TRANSACTION',font=lfont)
    canvas2.create_window(118,300, window=i)
    j=Label(r,text='CATOGORY',font=lfont)
    canvas2.create_window(75,350, window=j)

    def inform(r,infor):
        global photo
        def info1(r,infor):
            r.destroy()
            global photo,icon
            r = Toplevel()
            r.geometry("1100x700")
            r.title('₹ MY WALLET ₹')
            r.config(bg='white')
            r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
            canvas1 = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            labelfont=('times',30,'italic')
            icon = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
            p=Label(r,image=icon,bg="deepskyblue3")
            canvas1.create_window(100, 50, window=p)    
            a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)    
            canvas1.create_window(550, 50, window=a)                                         #adding the heading label to the canvas
            canvas1 = Canvas(r, width = 4000, height = 50,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            b=Label(r,text='$ Lets manage your money together $',fg='white',bg='deepskyblue3',font=('times',22,'italic'))
            canvas1.create_window(550,25, window=b)                                          #adding the heading label to the canvas
            d=Button(r,text="<<Back",bg="deepskyblue3",fg="white",command=lambda:expinfo(r,infor))
            canvas1.create_window(30,30, window=d)    
            canvas1 = Canvas(r, width = 4000, height = 800,bg="white")                 #creation of the subheading canvas
            canvas1.pack()
            labelfont=('times',30,'italic',"underline")
            a=Label(r,text='INFO',fg='deepskyblue3',bg='white',font=labelfont)
            canvas1.create_window(550,40, window=a)
            b=Label(r,text='What Is Considered to Be a Living Expense?',bg="white",font=labelfont)
            canvas1.create_window(600,100, window=b)

            labelfont=('times',13,'bold','underline')
            c=Label(r,text='Housing:\n Whether you rent or own, there are regular expenses, including some you\n may not be aware of.',fg='black',bg='lightgrey',font=labelfont)
            canvas1.create_window(750,150, window=c)
            lfont=('times',10,'italic')
            d=Label(r,text='•Mortgage payment or monthly rent \n •Utilities \n ',fg='black',bg='white',font=lfont)
            canvas1.create_window(650,220, window=d)
            lablefont=('times',13,'bold','underline')
            e=Label(r,text='Food and grocery: \n Besides your daily meals, consider other living necessities.',fg='black',bg='lightgrey',font=lablefont)
            canvas1.create_window(700,290, window=e)
            lfont=('times',10,'italic')
            f=Label(r,text='•Food and beverages \n •snacks \n •breakfast/lunch/dinner',fg='black',bg='white',font=lfont)
            canvas1.create_window(700,350, window=f)
            lablefont=('times',13,'bold','underline')
            g=Label(r,text='Clothing:\n From your work clothes to pajamas, ensure you account for everyone in your family.',fg='black',bg='lightgrey',font=lablefont)
            canvas1.create_window(400,410, window=g)
            lfont=('times',10,'italic')
            h=Label(r,text='•Daily clothing \n •Formal wear \n •Boots, shoes, and coats',fg='black',bg='white',font=lfont)
            canvas1.create_window(390,470, window=h)


            button=Button(r,text='[1]→',activeforeground='blue',width=5,height=1,bg='deepskyblue3',fg="white",command=lambda:info2(r,infor))
            canvas1.create_window(550,500, window=button)

            photo = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\catogory.png")
            canvas1.create_image(200,250, image=photo)

        def info2(r,infor):
            r.destroy()
            global photo,icon
            r = Toplevel()
            r.geometry("1100x700")
            r.title('₹ MY WALLET ₹')
            r.config(bg='white')
            r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
            canvas1 = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            labelfont=('times',30,'italic')
            icon = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
            p=Label(r,image=icon,bg="deepskyblue3")
            canvas1.create_window(100, 50, window=p)    
            a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)    
            canvas1.create_window(550, 50, window=a)                                         #adding the heading label to the canvas
            canvas1 = Canvas(r, width = 4000, height = 50,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            b=Label(r,text='$ Lets manage your money together $',fg='white',bg='deepskyblue3',font=("times",22,'italic'))
            canvas1.create_window(550,25, window=b)                                          #adding the heading label to the canvas
                
            canvas1 = Canvas(r, width = 4000, height = 800,bg="white")                 #creation of the subheading canvas
            canvas1.pack()
            labelfont=('times',30,'italic',"underline")
            a=Label(r,text='INFO',fg='deepskyblue3',bg='white',font=labelfont)
            canvas1.create_window(550,40, window=a)
            b=Label(r,text='What Is Considered to Be a Living Expense?',bg="white",font=labelfont)
            canvas1.create_window(600,100, window=b)


            labelfont=('times',13,'bold','underline')
            c=Label(r,text='Healthcare:\n Remember to include expenses for your primary doctor, dentist, and other specialists',fg='black',bg='lightgrey',font=labelfont)
            canvas1.create_window(750,150, window=c)
            lfont=('times',10,'italic')
            d=Label(r,text='•Insurance premiums \n •Office copays \n •Pharmacy copays \n •Over-the-counter item',fg='black',bg='white',font=lfont)
            canvas1.create_window(650,220, window=d)
            lablefont=('times',13,'bold','underline')
            e=Label(r,text='Transportation:\n Depending on whether you take the bus or drive a car, add up your regular\n transportation costs.',fg='black',bg='lightgrey',font=lablefont)
            canvas1.create_window(710,290, window=e)
            lfont=('times',10,'italic')
            f=Label(r,text='•Car payment &•Car insurance \n •Gas \n •Public transportation tickets & Taxi costs\n •Parking fees & toll tax\n •bus/train/aeroplane',fg='black',bg='white',font=lfont)
            canvas1.create_window(650,370, window=f)
            lablefont=('times',13,'bold','underline')
            g=Label(r,text='Entertainment: \nthe action of providing or being provided with amusement or enjoyment.',fg='black',bg='lightgrey',font=lablefont)
            canvas1.create_window(400,410, window=g)
            lfont=('times',10,'italic')
            h=Label(r,text='Movie\n •Sports\n •',fg='black',bg='white',font=lfont)
            canvas1.create_window(390,470, window=h)


            button=Button(r,text='←[1]',activeforeground='blue',width=5,height=1,bg='deepskyblue3',fg="white",command=lambda:info1(r,infor))
            canvas1.create_window(500,500, window=button)
            button=Button(r,text='[3]→',activeforeground='blue',width=5,height=1,bg='deepskyblue3',fg="white",command=lambda:info3(r,infor))
            canvas1.create_window(550,500, window=button)

            photo = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\catogory.png")
            canvas1.create_image(200,250, image=photo)
        def info3(r,infor):
            r.destroy()
            global photo,icon
            r = Toplevel()
            r.geometry("1100x700")
            r.title('₹ MY WALLET ₹')
            r.config(bg='white')
            r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
            canvas1 = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            labelfont=('times',30,'italic')
            icon = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
            p=Label(r,image=icon,bg="deepskyblue3")
            canvas1.create_window(100, 50, window=p)    
            a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)    
            canvas1.create_window(550, 50, window=a)                                         #adding the heading label to the canvas
            canvas1 = Canvas(r, width = 4000, height = 50,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            b=Label(r,text='$ Lets manage your money together $',fg='white',bg='deepskyblue3',font=('times',22,'italic'))
            canvas1.create_window(550,25, window=b)                                          #adding the heading label to the canvas
                
            canvas1 = Canvas(r, width = 4000, height = 800,bg="white")                 #creation of the subheading canvas
            canvas1.pack()
            labelfont=('times',30,'italic','underline')
            a=Label(r,text='INFO',fg='deepskyblue3',bg='white',font=labelfont)
            canvas1.create_window(550,40, window=a)
            b=Label(r,text='What Is Considered to Be a Living Expense?',bg="white",font=labelfont)
            canvas1.create_window(600,100, window=b)


            labelfont=('times',13,'bold','underline')
            c=Label(r,text='Loan: \nWhen money is given to another party in exchange for repayment of the loan\n principal amount plus interest',fg='black',bg='lightgrey',font=labelfont)
            canvas1.create_window(750,150, window=c)
            lfont=('times',10,'italic')
            d=Label(r,text='•Housing loan \n •Education loan \n •Personal Loan',fg='black',bg='white',font=lfont)
            canvas1.create_window(650,220, window=d)
            lablefont=('times',13,'bold','underline')
            e=Label(r,text='Tax:\n A compulsory contribution to state revenue, levied by the government on\n workers income.',fg='black',bg='lightgrey',font=lablefont)
            canvas1.create_window(750,290, window=e)
            lfont=('times',10,'italic')
            f=Label(r,text='•vehicle tax \n •Property tax \n •others',fg='black',bg='white',font=lfont)
            canvas1.create_window(650,370, window=f)
            g=Label(r,text='Insurance: \nan arrangement by which a company or the state undertakes to provide a guarantee of compensation for specified loss.',fg='black',bg='lightgrey',font=lablefont)
            canvas1.create_window(400,410, window=g)
            lfont=('times',10,'italic')
            h=Label(r,text='Auto\n •Health\n •life',fg='black',bg='white',font=lfont)
            canvas1.create_window(390,470, window=h)
            button=Button(r,text='←[2]',activeforeground='blue',width=5,height=1,fg='white',bg="deepskyblue3",command=lambda:info2(r,infor))
            canvas1.create_window(500,500, window=button)
            button=Button(r,text='[4]→',activeforeground='blue',width=5,height=1,bg='deepskyblue3',fg="white",command=lambda:info4(r,infor))
            canvas1.create_window(550,500, window=button)


            photo = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\catogory.png")
            canvas1.create_image(200,250, image=photo)


        def info4(r,infor):
            r.destroy()
            global photo,icon
            r = Toplevel()
            r.geometry("1100x700")
            r.title('₹ MY WALLET ₹')
            r.config(bg='white')
            r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
            canvas1 = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            labelfont=('times',30,'italic')
            icon = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
            p=Label(r,image=icon,bg="deepskyblue3")
            canvas1.create_window(100, 50, window=p)    
            a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)    
            canvas1.create_window(550, 50, window=a)                                         #adding the heading label to the canvas
            canvas1 = Canvas(r, width = 4000, height = 50,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            b=Label(r,text='$ Lets manage your money together $',fg='white',bg='deepskyblue3',font=('times',22,'italic'))
            canvas1.create_window(550,25, window=b)                                          #adding the heading label to the canvas
                
            canvas1 = Canvas(r, width = 4000, height = 800,bg="white")                 #creation of the subheading canvas
            canvas1.pack()
            labelfont=('times',30,'italic','underline')
            a=Label(r,text='INFO',fg='deepskyblue3',bg='white',font=labelfont)
            canvas1.create_window(550,40, window=a)
            b=Label(r,text='What Is Considered to Be a Living Expense?',bg="white",font=labelfont)
            canvas1.create_window(600,100, window=b)
            labelfont=('times',13,'bold','underline')
            c=Label(r,text='Travel:\n move, typically in a constant or predictable way..',fg='black',bg='lightgrey',font=labelfont)
            canvas1.create_window(750,150, window=c)
            lfont=('times',10,'italic')
            d=Label(r,text='•bus/airplane/train \n •food \n •hotel ',fg='black',bg='white',font=lfont)
            canvas1.create_window(650,220, window=d)
            lablefont=('times',13,'bold','underline')
            e=Label(r,text='Utilities: \n The total satisfaction received from consuming a good or service .',fg='black',bg='lightgrey',font=lablefont)
            canvas1.create_window(700,290, window=e)
            lfont=('times',10,'italic')
            f=Label(r,text='•water/gas/electricities \n •telephone/mobile/television \n •Internet',fg='black',bg='white',font=lfont)
            canvas1.create_window(700,350, window=f)
            lablefont=('times',13,'bold','underline')
            g=Label(r,text='Miscellaneous:\n various types or from different sources other than given .',fg='black',bg='lightgrey',font=lablefont)
            canvas1.create_window(400,410, window=g)
            lfont=('times',10,'italic')

            
            button=Button(r,text='←[3]',activeforeground='blue',width=5,height=1,fg='white',bg="deepskyblue3",command=lambda:info3(r,infor))
            canvas1.create_window(550,500, window=button)
            


            photo = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\catogory.png")
            canvas1.create_image(200,250, image=photo)

            
            
        info1(r,infor)
    font=("aerial",10,"italic")

    if infor==1:
        e1=Entry(r,bg='white',font=font)
        canvas2.create_window(300,100, window=e1)
        e2=Entry(r,bg='white',font=font)
        canvas2.create_window(300,50, window=e2)
        cudate.set(curdate)
        print(type(cudate))
        e3=Entry(r,bg='white',font=font,text=cudate)
        canvas2.create_window(300,150, window=e3)
        e4=Text(r,bg='white',font=font,height=5,width=20)
        canvas2.create_window(300,225, window=e4)
        e4.insert(END,"")
    else:
        pf=StringVar()
        amt=StringVar()
        date=StringVar()
        des=infor[3]
        dat=str(infor[2]).split("-")
        da=dat[2]+"."+dat[1]+"."+dat[0]
        pf.set(infor[1])
        amt.set(infor[0])
        date.set(da)
            
        e1=Entry(r,bg="white",font=font,text=amt)
        canvas2.create_window(300,100, window=e1)
        e2=Entry(r,bg='white',font=font,text=pf)
        canvas2.create_window(300,50, window=e2)
            
        e3=Entry(r,bg='white',font=font,text=date)
        canvas2.create_window(300,150, window=e3)
        e4=Text(r,bg='white',font=font,height=5,width=20)
        canvas2.create_window(300,225, window=e4)
        e4.insert(END,des)
        
    lb = Listbox(r, height =8, width =20,bg = "white",activestyle = 'dotbox',font =font, fg = "black")
    canvas2.create_window(300,400, window=lb)
    def CurSelet(evt):
        global value
        value=lb.get(lb.curselection())
                     
        
    cat=["Housing",'Entertainment','Family','Insurence','Travel','Utilities',"Food and grocery","Clothing","Healthcare","Transportation","Loan","Tax","Miscellaneous"]
    for i in cat:
        lb.insert(END,i)
    lb.bind('<<ListboxSelect>>',CurSelet)
    k=Label(r,text='''(*Help us organise your
        expenses in a better way)''',bg="skyblue",fg="red",font=font)
    canvas2.create_window(100,390, window=k)
    photo = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\info.png") 
    h=Button(r,image=photo,bg="white",command=lambda:inform(r,infor))
    canvas2.create_window(145,350, window=h)
    global w
    global fname
    fname=""

    w=IntVar()
    w.set(0)
    c1=Checkbutton(r, text = "Other means", variable = w, onvalue = 0,offvalue =1,bg='white',fg='black')
    canvas2.create_window(275,300, window=c1)
    c2=Checkbutton(r, text = "Cash in hand",variable = w,onvalue = 1,offvalue=0,bg='white',fg='bLack')
    canvas2.create_window(400,300, window=c2)
    def saveimg():
        global fname
        fname = filedialog.askopenfilename(title ='Select file')
        le=len(fname)
        if fname[(le-4):]==".jpg" or fname[(le-4):]==".jpeg" or fname[(le-4):]==".png":
            fname=fname
            messagebox.showinfo("SUCCESS","Upload successful!!!")
        else:
            messagebox.showwarning("ERROR","Please upload .jpg or .jpeg or.png file only")
        print(fname,"hi")

    def save(r,infor):
        if infor==1:
            MsgBox = messagebox.askquestion ('Save','Are you sure you want to save the given values?')
        else:
            MsgBox = messagebox.askquestion ('Save','Are you sure you want to Edit your values?')
        if MsgBox == 'yes':
            count=0
            
            global w,info,value,budget
            global fname
            print(value)
            inf=info[0][3]
            if fname=="":
                fname="None"
            datef=""    
            n=' '
            amt=e1.get()
            uf=e2.get()
            f=e3.get()
            descr=""    
                
            l=e4.get("1.0", "end")
            l.rstrip("")
            for b in range(0,len(l),20):
                descr+=l[b:b+20]+'\n'
            print(len(descr),descr,"hi")
            if w.get()==0:
                mot='other means'
            else:
                mot='cash in hand'
            print(datef)       
            dmy=f.split('.')
            dmy.reverse()
            print(dmy)
            if (amt!="" and uf!="" and len(dmy)==3 and value!=""):
                count+=1
                print("d")
            if amt.isdigit():
                count+=1
                print("a")
            """if uf.isalpha():
                count+=1
                print("b")"""
            if (f[0:2].isdigit())and(f[2]=='.')and(f[3:5].isdigit())and(f[5]=='.')and(f[6:].isdigit())and(len(f)==10):
                count+=1
                print("c")
                dd=int(dmy[2])
                mm=int(dmy[1])
                yy=int(dmy[0])
                if((mm < 1 or mm > 12)or(dd < 1 or dd > 31)):
                    messagebox.showwarning("ERROR"," ENTER VALID DATE1")
                    return 10
                else:
                    if mm == 1 or mm == 3 or mm == 5 or mm == 7 or mm == 8 or mm == 10 or mm == 12:
                        max_day_value = 31
                    elif mm == 4 or mm == 6 or mm == 9 or mm == 11:
                        max_day_value = 30
                    elif yy % 4 == 0 and yy % 100 != 0 or yy % 400 == 0:
                        max_day_value = 29
                    else:
                        max_day_value = 28
                    if dd > max_day_value:
                        messagebox.showwarning("ERROR"," ENTER VALID DATE")
                        return 
            else:
                print(count)
            for a in dmy:
                datef+=a
                
            if count==3:
                mon=str(budget[0][3]).split('-')
                
                if int(mon[1])==mm:
                    print("ii")
                    cursor.execute("select sum(amount) from expence where email=%s and month(date)=month(%s)",[budget[0][0],budget[0][3]])
                    print(str(budget[0][3]).split('-'))
                    curamt=e1.get()
                    a=cursor.fetchall()
                    print(a)
                    if a[0][0]==None:
                        a[0]=(0,)
                    if budget[0][2]<=(a[0][0]+int(curamt)):
                        print("hi")
                        msg=messagebox.showinfo("Error","You are exceeing your budget limit....\nPlease make changes to your current budget to continue")
                        cursor.execute('update budget set bcross=%s where email=%s',[int(budget[0][4])+1,budget[0][0]])
                        cursor.execute('select * from budget')
                        budget=cursor.fetchall()
                        print(budget)
                        if int(budget[0][4])>=3:
                            a=budget[0][4]
                            messagebox.showwarning("Warning","Budget limit exceeded "+str(a)+" times this month.....\
                                                \nPlease spend your money more wisely to maintain good savings!!!")
                        expinfo(r,3)
                        return
                
                if infor!=1:
                    cursor.execute("delete from expence where AMOUNT=%s and USEDFOR=%s and DATE=%s and DESCRIPTION=%s and MODEOFTRANSACTION=%s and BILL=%s and \
CATOGORY=%s and email=%s",[infor[0],infor[1],infor[2],infor[3],infor[4],infor[5],infor[6],inf])
                    
                    cursor.execute("insert into expence values(%s,%s,%s,%s,%s,%s,%s,%s)",[amt,uf,datef,descr,mot,fname,value,inf])
                    messagebox.showinfo("Edit","Successfully edited data")
                    gui=alltrans1(r)
                else:
                    cursor.execute("insert into expence values(%s,%s,%s,%s,%s,%s,%s,%s)",[amt,uf,datef,descr,mot,fname,value,inf])
                    messagebox.showinfo("Save","Successfully inserted data")
                    e1.delete(0,'end')
                    e2.delete(0,'end')
                    e4.delete(1.0,'end')
            else:
                messagebox.showwarning("ERROR"," ENTER VALID VALUES")
    
                
            
    def delete():
        global info
        inf=info[0][3]
        MsgBox = messagebox.askquestion ('Delete','Are you sure you want to save delete this record?')
        if MsgBox=="yes":
            cursor.execute("delete from expence where AMOUNT=%s and USEDFOR=%s and DATE=%s and DESCRIPTION=%s and MODEOFTRANSACTION=%s and BILL=%s and \
CATOGORY=%s and email=%s",[infor[0],infor[1],infor[2],infor[3],infor[4],infor[5],infor[6],inf])
            messagebox.showinfo("Delete","This record has been deleted...!")
            gui=alltrans1(r)
            
        
    if infor==1:
        button1=Button(r,text='SAVE',command=lambda:save(r,infor),bg="deepskyblue3",fg="white",width=10,height=2)
        canvas2.create_window(350,500, window=button1)
        button2=Button(r,text='UPLOAD BILL(optional)',command=saveimg,width=20,bg="deepskyblue3",fg="white",height=2)
        canvas2.create_window(150,500, window=button2)
    
    else:
        button2=Button(r,text='UPLOAD BILL(optional)',command=saveimg,width=20,bg="deepskyblue3",fg="white",height=2)
        canvas2.create_window(150,500, window=button2)
        button1=Button(r,text='EDIT',bg="deepskyblue3",command=lambda:save(r,infor),fg="white",width=10,height=2)
        canvas2.create_window(400,500, window=button1)
        button3=Button(r,text='DELETE',bg="red",fg="white",command=delete,width=10,height=2)
        canvas2.create_window(285,500, window=button3)
    
        
    
              
   
def alltrans1(r):
    global photo,photo1,photo2,photo3,icon
    r.destroy()
    r = Toplevel()
    r.geometry("1100x800")
    r.title('₹ MY WALLET ₹')
    r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
    r.config(bg='white')
    canvas1 = Canvas(r, width = 4000, height = 100,bg="SteelBlue3")              
    canvas1.pack()
    icon = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
    i=Label(r,image=icon,bg="SteelBlue3")
    canvas1.create_window(100, 50, window=i) 
    labelfont=('times',30,'italic')
    lfont=("times",15,'italic')   
    a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='SteelBlue3',font=labelfont)    
    canvas1.create_window(550, 50, window=a)

    canvas11 = Canvas(r, width = 4000, height = 45,bg="SteelBlue")              
    canvas11.pack()
    labelfont=('times',20,'italic')
    b=Label(r,text='$ Lets manage your money together $',fg='white',bg='SteelBlue',font=labelfont)
    canvas11.create_window(600,25, window=b)
    
    canvas1 = Canvas(r, width = 4000, height=50,bg="SteelBlue2")              
    canvas1.pack()
    c=Label(r,text='ALL TRANSACTIONS',fg='white',bg='SteelBlue2',font=labelfont)
    canvas1.create_window(550,25, window=c)

    f=Button(r,text="<<Back",bg="deepskyblue3",command=lambda:homepg(r),fg="white")
    canvas1.create_window(30,25, window=f)
    
    canvas1 = Canvas(r, width = 4000, height =1000,bg="antiquewhite2")              
    canvas1.pack()

    photo = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\weeklyrep.png") 
    a1=Button(r, text = 'THIS MONTH', image = photo,compound=TOP,fg='white',bg='SteelBlue2',command=lambda:alltrans(r,1),font=lfont)
    canvas1.create_window(850, 270, window=a1)       

    photo2 = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\yearly.png") 
    a3=Button(r, text = 'ALL', image = photo2,compound=TOP,fg='white',bg='SteelBlue2',command=lambda:alltrans(r,2),font=lfont)
    canvas1.create_window(350, 270, window=a3)


    
    def alltrans(r,inp):
        
        global info,icon,budget
        
        
        def button(r,canvas2,c,i,b,cat):
            print("hi1")
            a=Button(r,text="Edit"+" "+b[i][1],bg="green",fg="white",font=("aerial",10,"bold"),command=lambda:expinfo(r,b[i]+(cat,)))
            canvas2.create_window(1000,c, window=a)
        def genrep(cat):
            global table
            
            with open(cat+'.txt','w') as f:
                f.write(cat+'\n')
                f.write(table)
            messagebox.showinfo("Success","Report generated")
       
            
        def click(a,r,inp):
            global info,icon,budget
            cat=a[0]
            r.destroy()
            r =Toplevel()
            r.geometry("1100x700")
            canvas1 = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")
            canvas1.pack()
            r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
            icon = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
            p=Label(r,image=icon,bg="deepskyblue3")
            canvas1.create_window(100, 50, window=p) 
            r.title('₹ MY WALLET ₹')
            r.config(bg='white')
            labelfont=('times',30,'italic')
            lfont=('times',15,'italic')
            lafont=('times',20,'bold')
            a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)
            canvas1.create_window(550, 50, window=a)
            
            canvas2 = Canvas(r, width = 4000, height = 50,bg="deepskyblue2")
            canvas2.pack()
            lfont1=('times',20,'italic')
            b=Label(r,text='$ Lets manage your money together $',fg='white',bg='deepskyblue2',font=lfont1)
            canvas2.create_window(550,25, window=b)
            canvas11 = Canvas(r, width = 4000, height = 50,bg="deepskyblue2")
            canvas11.pack()
            lfont2=('times',20,'italic')
            e=Label(r,text=cat,fg='white',bg='deepskyblue2',font=lfont2)
            canvas11.create_window(550,25, window=e)
            f=Button(r,text="<<Back",bg="deepskyblue3",command=lambda:alltrans1(r),fg="white")
            canvas11.create_window(30,25, window=f)
            
            
            frame = Frame(r, width = 4000, height =1000,bg="blue")
            frame.pack()
            canvas2 = Canvas(frame, width = 4000, height =1000,scrollregion=(0,0,4500,3000),bg="ghost white")
            
            vbar=Scrollbar(frame,orient=VERTICAL)
            vbar.pack(side=RIGHT,fill=Y)
            vbar.config(command=canvas2.yview)
            canvas2.config(width=4000,height=1000)
            canvas2.config(yscrollcommand=vbar.set)
            canvas2.pack()
            if inp==1:
                print("hi1")
                custor.execute("select AMOUNT,USEDFOR,DATE,DESCRIPTION,MODEOFTRANSACTION,BILL from expence where \
                               CATOGORY=%s and email=%s and month(date)=month(%s) order by DATE desc",[cat,info[0][3],budget[0][3]])
                b=custor.fetchall()
            elif inp==2:
                print("hi")
                custor.execute("select AMOUNT,USEDFOR,DATE,DESCRIPTION,MODEOFTRANSACTION,BILL from expence where \
                               CATOGORY=%s and email=%s order by DATE desc",[cat,info[0][3]])
                b=custor.fetchall()
                
                    
            print(b)
            d=[]
            c=((50*len(b))/2)-(len(b)*2)
            for i in range(len(b)):
                d.append(b[i][:len(b[i])-1])
                button(r,canvas2,c,i,b,cat)
               
                c+=(b[i][3].count('\n')*17)
            global table    
            print(b)
            headers=["AMOUNT","USED FOR","DATE","DESCRIPTION","MODE OF TRANSACTION"]
            table=tabulate(d,headers,tablefmt="grid",numalign="right",stralign="left")
           
            d=Label(r,text=table,font=("courier new",10),bg="GHOST white")
            canvas2.create_window(550,len(b)*50, window=d)
            g=Button(r,text="Generate Report",command=lambda:genrep(cat),bg="deepskyblue3",fg="white")
            canvas11.create_window(1000,25, window=g)
            
            

        global info,icon
        print(info)
        r.destroy()
        r =Toplevel()
        r.geometry("1100x700")
        canvas1 = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")
        canvas1.pack()
        r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
        icon = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
        p=Label(r,image=icon,bg="deepskyblue3")
        canvas1.create_window(100, 50, window=p) 
        r.title('₹ MY WALLET ₹')
        r.config(bg='white')
        labelfont=('times',30,'italic')
        lfont=('times',15,'italic')
        lafont=('times',20,'bold')
        a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)
        canvas1.create_window(550, 50, window=a)
        
        canvas2 = Canvas(r, width = 4000, height = 50,bg="deepskyblue2")
        canvas2.pack()
        lfont1=('times',20,'italic')
        b=Label(r,text='$ Lets manage your money together $',fg='white',bg='deepskyblue2',font=lfont1)
        canvas2.create_window(550,25, window=b)
        canvas11 = Canvas(r, width = 4000, height = 50,bg="deepskyblue2")
        canvas11.pack()
        lfont2=('times',20,'italic')
        e=Label(r,text='ALL TRANSACTION',fg='white',bg='deepskyblue2',font=lfont2)
        canvas11.create_window(550,25, window=e)
        f=Button(r,text="<<Back",bg="deepskyblue3",command=lambda:homepg(r),fg="white")
        canvas11.create_window(30,25, window=f)
        

        if inp==1:
            custor.execute("select CATOGORY,sum(AMOUNT) from expence where email=%s and month(date)=month(%s) group by CATOGORY ",[info[0][3],budget[0][3]])
            a=custor.fetchall()
        elif inp==2:
            custor.execute("select CATOGORY,sum(AMOUNT) from expence where email=%s  group by CATOGORY ",[info[0][3]])
            a=custor.fetchall()
            
        print(b)
        frame = Frame(r, width = 4000, height =1000,bg="blue")
        frame.pack()
        canvas2 = Canvas(frame, width = 4000, height =1000,scrollregion=(0,0,4500,3000),bg="white")
            
        vbar=Scrollbar(frame,orient=VERTICAL)
        vbar.pack(side=RIGHT,fill=Y)
        vbar.config(command=canvas2.yview)
        canvas2.config(width=4000,height=1000)
        canvas2.config(yscrollcommand=vbar.set)
        canvas2.pack()

        c=85
        sno=1
        canvas = Canvas(canvas2, width = 500, height =65,bg="ghost white")
        canvas2.create_window(550,35, window=canvas)
        d=Label(r,text="S.NO",font=lfont,bg="GHOST white")
        canvas.create_window(50,35, window=d)
        e=Label(r,text="CATOGORY",font=lfont,bg="ghostwhite")
        canvas.create_window(150,35, window=e)
        f=Label(r,text="AMOUNT",font=lfont,bg="ghostwhite")
        canvas.create_window(275,35, window=f)
        for b in a:
            canvas = Canvas(canvas2, width = 500, height =65,bg="ghost white")
            canvas2.create_window(550,c, window=canvas)
            d=Label(r,text=str(sno)+'.',font=lfont,bg="white")
            canvas.create_window(50,35, window=d)
            e=Label(r,text=b[0],font=lfont,bg="white")
            canvas.create_window(150,35, window=e)
            f=Label(r,text=b[1],font=lfont,bg="white")
            canvas.create_window(270,35, window=f)
            g=Button(r,text="View",bg="green",fg="white",font=("aerial",10,"bold"),command=partial(click,b,r,inp))
            
            canvas.create_window(400,35, window=g)
            print(b)
            c+=65
            sno+=1
       
        r.mainloop()
    


def reports(r):
    global photo,photo1,photo2,photo3,icon
    r.destroy()
    r = Toplevel()
    r.geometry("1100x800")
    r.title('₹ MY WALLET ₹')
    r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
    r.config(bg='white')
    canvas1 = Canvas(r, width = 4000, height = 100,bg="SteelBlue3")              
    canvas1.pack()
    icon = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
    i=Label(r,image=icon,bg="SteelBlue3")
    canvas1.create_window(100, 50, window=i) 
    labelfont=('times',30,'italic')
    lfont=("times",15,'italic')   
    a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='SteelBlue3',font=labelfont)    
    canvas1.create_window(550, 50, window=a)

    canvas11 = Canvas(r, width = 4000, height = 45,bg="SteelBlue")              
    canvas11.pack()
    labelfont=('times',20,'italic')
    b=Label(r,text='$ Lets manage your money together $',fg='white',bg='SteelBlue',font=labelfont)
    canvas11.create_window(600,25, window=b)
    
    canvas1 = Canvas(r, width = 4000, height=50,bg="SteelBlue2")              
    canvas1.pack()
    c=Label(r,text='REPORTS',fg='white',bg='SteelBlue2',font=labelfont)
    canvas1.create_window(550,25, window=c)

    f=Button(r,text="<<Back",bg="deepskyblue3",command=lambda:homepg(r),fg="white")
    canvas1.create_window(30,25, window=f)
    
    canvas1 = Canvas(r, width = 4000, height =1000,bg="antiquewhite2")              
    canvas1.pack()

    photo = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\weeklyrep.png") 
    a1=Button(r, text = 'WEEKLY', image = photo,compound=TOP,fg='white',bg='SteelBlue2',command=lambda:weekly(),font=lfont)
    canvas1.create_window(950, 270, window=a1)       

    photo1 = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\monthlyrep.png") 
    a2=Button(r, text = 'MONTHLY', image = photo1,compound=TOP,fg='white',bg='SteelBlue2',command=lambda:monthly(),font=lfont)
    canvas1.create_window(590, 270, window=a2)       

    photo2 = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\yearly.png") 
    a3=Button(r, text = 'YEARLY', image = photo2,compound=TOP,fg='white',bg='SteelBlue2',command=lambda:yearly(),font=lfont)
    canvas1.create_window(250, 270, window=a3)

    def weekly():
        
        global info
        r = Tk
        print(info)
        date_object = str(datetime.date(datetime.now()))
        a=str(date_object)
        if a[8::]>="08":
            date=int(a[8::])-7
            weekdate=str(date)
            month=a[5:7]
            year=a[0:4]
        else:
            #31 days
            if a[5:7] in ["01","03","05","07","08","10","12"]:
                dicdate={"01":"24","02":"25","03":"26","04":"27","05":"28","06":"29","07":"30"}
                for d in dicdate:
                    if a[8::]==d:
                        weekdate=dicdate[d]
                if a[5:7]=="01":
                    month="12"
                    yr=int(a[0:4])-1
                    year=str(yr)
                else:
                    mon=int(a[5:7])-1
                    yr=a[0:4]
                    print(mon)
                    year=a[0:4]
                    if str(mon)=="11":
                        month="11"
                    else:
                        month="0"+str(mon)
            elif a[5:7]=="02":
                #feb alone
                dicdate30={"01":"25","02":"26","03":"27","04":"28","05":"29","06":"30","07":"31"}
                for d in dicdate30:
                    if a[8::]==d:
                        weekdate=dicdate30[d]
                mon=int(a[5:7])-1
                month="0"+str(mon)
                weekdate=str(date)
                year=a[0:4]
            else:
                #30days
                date=30-int(a[8::])
                weekdate=str(date)
                year=a[0:4]
                mon=int(a[5:7])-1
                if mon=="10":
                    month="10"
                else:
                    month="0"+str(mon)
        finaldate=str(year+"."+month+"."+weekdate)
        print("WEEKDATE:",finaldate)
        custor.execute("select CATOGORY,sum(AMOUNT) from expence where email=%s and DATE>%s group by CATOGORY ",[info[0][3],finaldate])
        a=custor.fetchall()
        for w in a:
            print("dffgh",w)
        category=[]
        cost=[]
        count=0
        for b in a:
            count+=1
            category.append(b[0])
            cost.append(b[1])
            print("werty",b)
        explist=[]
        for coun in range(0,count,1):
            explist.append(0.1)
        expl=tuple(explist)
        matplotlib.pyplot.axis("equal")
        matplotlib.pyplot.title(label='₹€ MY WALLET ₹€\n'+'REPORTS ON WEEKLY BASIS:', loc="center", fontstyle='italic',fontweight='bold',bbox={'facecolor':'none', 'pad':5}) 
        matplotlib.pyplot.pie(cost,labels=category,shadow = True, explode = expl,autopct="%1.1f%%",startangle=140)
        matplotlib.pyplot.show()

    def monthly():
        global info
        r = Tk
        print(info)
        date_object = str(datetime.date(datetime.now()))
        a=str(date_object)
        print("sssssssssss",a)
        mon=a[5:7]
        olddate=a[8::]
        if a[5:7] in ["04","06","09","11"] and a[8::]=="31":
            date="30"
        else:
            date=olddate
        if  mon=="01":
            month="12"
            yr=int(a[0:4])-1
            year=str(yr)
        else:
            month=str(int(a[5:7])-1)
            year=a[0:4]
        finaldate=str(year+"."+month+"."+date)
        print("MONTHDATE",finaldate)
        custor.execute("select CATOGORY,sum(AMOUNT) from expence where email=%s and DATE>%s group by CATOGORY ",[info[0][3],finaldate])
        a=custor.fetchall()
        for w in a:
            print("dffgh",w)
        category=[]
        cost=[]
        count=0
        for b in a:
            count+=1
            category.append(b[0])
            cost.append(b[1])
            print("werty",b)
        explist=[]
        for coun in range(0,count,1):
            explist.append(0.1)
        expl=tuple(explist)
        matplotlib.pyplot.axis("equal")
        matplotlib.pyplot.title(label='₹€ MY WALLET ₹€\n'+'REPORTS ON MONTHLY BASIS:', loc="center", fontstyle='italic',fontweight='bold',bbox={'facecolor':'none', 'pad':5}) 
        matplotlib.pyplot.pie(cost,labels=category,shadow = True, explode = expl,autopct="%1.1f%%",startangle=140)
        matplotlib.pyplot.show()

    def yearly():
        global info
        r = Tk
        print(info)
        date_object = str(datetime.date(datetime.now()))
        a=str(date_object)
        print("sssssssssss",a)
        month=a[5:7]
        date=a[8::]
        yr=int(a[0:4])-1
        year=str(yr)
        finaldate=str(year+"."+month+"."+date)
        print("MONTHDATE",finaldate)
        custor.execute("select CATOGORY,sum(AMOUNT) from expence where email=%s and DATE>%s group by CATOGORY ",[info[0][3],finaldate])
        a=custor.fetchall()
        for w in a:
            print("dffgh",w)
        category=[]
        cost=[]
        count=0
        for b in a:
            count+=1
            category.append(b[0])
            cost.append(b[1])
            print("werty",b)
        explist=[]
        for coun in range(0,count,1):
            explist.append(0.1)
        expl=tuple(explist)
        matplotlib.pyplot.axis("equal")
        matplotlib.pyplot.title(label='₹€ MY WALLET ₹€\n'+'REPORTS ON YEARLY BASIS:', loc="center", fontstyle='italic',fontweight='bold',bbox={'facecolor':'none', 'pad':5}) 
        matplotlib.pyplot.pie(cost,labels=category,shadow = True, explode = expl,autopct="%1.1f%%",startangle=140)
        matplotlib.pyplot.show()
        








def homepg(r):
    def logout(r):
        MsgBox = messagebox.askquestion ('Logout','Are you sure you want to Logout from your profile?')
        if MsgBox == 'yes':
            gui=home1(r)
    def edit():
        print("hi")
        global info,e1,e2,e3,e4,e5,e6,e7,e8,budget
        con = connector.connect(port="3308",user="root",password="",database="expencemanager")
        custor=con.cursor()
        count=0
        name1=e1.get()
        name2=e2.get()
        pro=e3.get()
        eid=e4.get()
        pas=e5.get()
        cno=e6.get()
        inco=e7.get()
        bud=e8.get()
        print(cno)
        if(name1=="" or name2=="" or pro=="" or eid=="" or pas==""or cno=="" or inco=="" or bud==""):
            messagebox.showinfo("Error","Fill all info even if no change required!!!")
            return
        if(len(pas)>=9 or cno.isdigit()!=True or len(cno)>=11  or inco.isdigit()!=True or bud.isdigit()!=True):
            count+=1
            print("A")
        if(eid.find("@gmail.com")!=-1 or eid.find("@yahoo.com")!=-1 ):
            count+=1
            print("B")
        if(count!=1):
            messagebox.showinfo("Error","Please enter valid datas")
        if(count==1):
            custor.execute("update userinfo set fname='"+name1+"',lname='"+name2+"',profes='"+pro+"',email='"+eid+"',\
                                    phone='"+cno+"',password='"+pas+"' where email='"+info[0][3]+"'" )
            custor.execute("update budget set income=%s,ibudget=%s where email=%s",[inco,bud,info[0][3]])
            custor.execute("update expence set email=%s where email=%s",[eid,info[0][3]])
            custor.execute("update budget set email=%s where email=%s",[eid,info[0][3]])
            custor.execute("select * from userinfo where email='"+eid+"'")
            a=custor.fetchall()
            info=a
            custor.execute("select * from budget where email='"+eid+"'")
            budget=custor.fetchall()
            messagebox.showinfo("Success","Edit Success")



        
    def profile(r):
        global info,e1,e2,e3,e4,e5,e6,e7,e8,budget
        r.destroy()
        r =Toplevel()
        r.geometry("1100x700")
        canvas1 = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")
        canvas1.pack()
        r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
        r.title('₹ MY WALLET ₹')
        r.config(bg='white')
        labelfont=('times',30,'italic')
        lfont=('times',15,'italic')
        lafont=('times',20,'bold')
        a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)
        canvas1.create_window(550, 50, window=a)
        
        canvas2 = Canvas(r, width = 4000, height = 50,bg="deepskyblue2")
        canvas2.pack()
        lfont1=('times',20,'italic')
        b=Label(r,text='$ Lets manage your money together $',fg='white',bg='deepskyblue2',font=lfont1)
        canvas2.create_window(550,25, window=b)
        canvas11 = Canvas(r, width = 4000, height = 50,bg="deepskyblue2")
        canvas11.pack()
        lfont2=('times',20,'italic')
        e=Label(r,text='EDIT PROFILE',fg='white',bg='deepskyblue2',font=lfont2)
        canvas11.create_window(550,25, window=e)
        f=Button(r,text="<<Back",bg="deepskyblue3",command=lambda:homepg(r),fg="white")
        canvas11.create_window(30,25, window=f)
        canvas2 = Canvas(r, width = 450, height = 600,bg="skyblue")
        canvas2.pack()
        print(info)    
        lfont=('aerial',10,'bold')
        f=Label(r,text='FIRST NAME',font=lfont)
        canvas2.create_window(77,50, window=f)
        e=Label(r,text='LAST NAME',font=lfont)
        canvas2.create_window(74,100, window=e)

        g=Label(r,text='PROFESSION',font=lfont)
        canvas2.create_window(77,150, window=g)
        h=Label(r,text='CONTACT NO',font=lfont)
        canvas2.create_window(77,200, window=h)
        i=Label(r,text='EMAIL ID',font=lfont)
        canvas2.create_window(70,250, window=i)
        j=Label(r,text='PASSWORD',font=lfont)
        canvas2.create_window(75,300, window=j)
        k=Label(r,text='CURRENT INCOME',font=lfont)
        canvas2.create_window(80,350, window=k)
        l=Label(r,text='CURRENT BUDGET',font=lfont)
        canvas2.create_window(80,400, window=l)

        a=Label(r,text=info[0][0],font=lfont,bg="white")
        canvas2.create_window(200,50, window=a)
        b=Label(r,text=info[0][1],font=lfont,bg="white")
        canvas2.create_window(200,100, window=b)

        c=Label(r,text=info[0][2],font=lfont,bg="white")
        canvas2.create_window(200,150, window=c)
        d=Label(r,text=info[0][4],font=lfont,bg="white")
        canvas2.create_window(200,200, window=d)
        e=Label(r,text=info[0][3],font=lfont,bg="white")
        canvas2.create_window(200,250, window=e)
        f=Label(r,text=info[0][5],font=lfont,bg="white")
        canvas2.create_window(200,300, window=f)
        g=Label(r,text=budget[0][1],font=lfont,bg="white")
        canvas2.create_window(200,350, window=g)
        h=Label(r,text=budget[0][2],font=lfont,bg="white")
        canvas2.create_window(200,400, window=h)
        
        font=("aerial",10,"italic")
        e1=Entry(r,bg='white',font=font,text=StringVar(r,value=info[0][0]))
        canvas2.create_window(350,50, window=e1)
        e2=Entry(r,bg='white',font=font,text=StringVar(r,info[0][1]))
        canvas2.create_window(350,100, window=e2) 
        e3=Entry(r,bg='white',font=font,text=StringVar(r,info[0][2]))
        canvas2.create_window(350,150, window=e3)
        e6=Entry(r,bg='white',font=font,text=StringVar(r,info[0][4]))
        canvas2.create_window(350,200, window=e6)
        e4=Entry(r,bg='white',font=font,text=StringVar(r,info[0][3]))
        canvas2.create_window(350,250, window=e4)
        e5=Entry(r,bg='white',font=font,text=StringVar(r,info[0][5]))
        canvas2.create_window(350,300, window=e5)
        e7=Entry(r,bg='white',font=font,text=StringVar(r,budget[0][1]))
        canvas2.create_window(350,350, window=e7)
        e8=Entry(r,bg='white',font=font,text=StringVar(r,budget[0][2]))
        canvas2.create_window(350,400, window=e8)
        
        button=Button(r,text='Edit',activeforeground='BLUE',width=10,height=2,bg="deepskyblue3",command=edit,fg="white")
        canvas2.create_window(200,450, window=button)
        
    def home(r):
        global photo,photo1,photo2,photo3,icon,info,budget
        custor.execute("select sum(amount) from expence where email=%s and month(date)=month(%s)",[budget[0][0],budget[0][3]])
        expence=custor.fetchall()
        if expence[0][0]==None:
            expence=[(0,)]
        r.destroy()
        r = Toplevel()
        r.geometry("1100x700")
         
        r.title('₹ MY WALLET ₹')
        r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
        r.config(bg='white')
        canvas1 = Canvas(r, width = 4000, height = 90,bg="firebrick3")              
        canvas1.pack()
        icon = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
        i=Label(r,image=icon,bg="firebrick3")
        canvas1.create_window(100, 50, window=i) 
        labelfont=('times',40,'italic')
        lfont=("times",15,'italic')   
        a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='firebrick3',font=labelfont)    
        canvas1.create_window(600, 50, window=a)

        canvas11 = Canvas(r, width = 4000, height = 60,bg="firebrick")              
        canvas11.pack()
            
        b=Label(r,text='$ Lets manage your money together $',fg='white',bg='firebrick',font=('times',25,'italic'))
        canvas11.create_window(600,30, window=b)
        
        canvas1 = Canvas(r, width = 4000, height=65,bg="indianred")              
        canvas1.pack()
        c=Label(r,text='HOME',fg='white',bg='indianred',font=('times',30,'italic'))
        canvas1.create_window(590,35, window=c)
        save=budget[0][1]-expence[0][0]
        photo3 = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\profile.png") 
        a1=Button(r, text =info[0][0] , image = photo3,compound=LEFT,command=lambda:profile(r),fg='black',bg='antiquewhite2',font=lfont)
        canvas1.create_window(1000, 35, window=a1)       
        a2=Button(r, text = 'Logout', fg='black',command=lambda:logout(r),bg='antiquewhite2',font=lfont)
        canvas1.create_window(100, 35, window=a2)       

        canvas1 = Canvas(r, width = 4000, height =1000,bg="antiquewhite2")              
        canvas1.pack()
        a=Label(r,text='Total Expence:'+str(expence[0][0]),fg='white',bg='green',font=('times',15,'italic'))
        canvas1.create_window(100,80, window=a)
        c=Label(r,text='Total Income:'+str(budget[0][1]),fg='white',bg='firebrick',font=('times',15,'italic'))
        canvas1.create_window(90,30, window=c)
        d=Label(r,text="Total Budget:"+str(budget[0][2]),fg='white',bg='firebrick',font=('times',15,'italic'))
        canvas1.create_window(950,30, window=d)

        b=Label(r,text="Budget Balance:"+str(budget[0][2]-expence[0][0]),fg='white',bg='green',font=('times',15,'italic'))
        canvas1.create_window(950,80, window=b)

        
        photo = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\alltrans.png") 
        a1=Button(r, text = 'ALL TRANSACTIONS', image = photo,compound=TOP,command=lambda:alltrans1(r),fg='white',bg='firebrick3',font=lfont)
        canvas1.create_window(950, 270, window=a1)       

        photo1 = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\report.png") 
        a2=Button(r, text = 'REPORTS',command=lambda:reports(r), image = photo1,compound=TOP,fg='white',bg='firebrick3',font=lfont)
        canvas1.create_window(250, 270, window=a2)       

        photo2 = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\addexp.png") 
        a3=Button(r, text = 'ADD EXPENSES', image = photo2,compound=TOP,command=lambda:expinfo(r,1),fg='white',bg='firebrick3',font=lfont)
        canvas1.create_window(590,270, window=a3)
    home(r)


def budget1(r):
    global info
    r.destroy()
    def conti(r):
        inco=e1.get()
        bud=e2.get()
        dte=datetime.date(datetime.now())
        eid=info[0][3]
        count=0
        print(inco,bud)
        if inco=="" or bud=="":
            messagebox.showwarning("Error","Please fill both the datas")
        elif inco.isdigit()==False or bud.isdigit()==False:
            messagebox.showwarning("Error","Please enter valid amount")
        elif int(inco)<int(bud):
            messagebox.showwarning("Error","Please enter a ideal budget less than your income")
        else:
            custor.execute("delete from budget where email=%s",[eid])
            custor.execute("insert into budget values(%s,%s,%s,%s,%s)",[eid,inco,bud,dte,0])
            custor.execute("select * from budget where email=%s",[eid])
            global budget
            budget=custor.fetchall()
            print(budget)
            homepg(r)
        
    
    r = Toplevel()
    r.title('₹ MY WALLET ₹')
    r.geometry("1100x700")
    r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
    
    canvas = Canvas(r, width = 4000, height = 90,bg="deepskyblue3")
    canvas.pack()
    
    r.config(bg='white')
    labelfont=('times',40,'italic')
    a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)
    canvas.create_window(550, 50, window=a)
    icon= PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
    i=Label(r,image=icon,bg="deepskyblue3")
    canvas.create_window(100, 50, window=i)
    

    canvas1 = Canvas(r, width = 4000, height = 60,bg="SkyBlue3")
    canvas1.pack()
    labelfont=('times',25,'italic')
    b=Label(r,text='$ Lets manage your money together $',fg='firebrick',bg='SkyBlue3',font=labelfont)
    canvas1.create_window(550, 25, window=b)
    
    canvas12 = Canvas(r, width = 1500, height = 50,bg="SkyBlue")
    canvas12.pack()
    labelfont1=('times',20,'italic')
    c1=Label(r,text='Please Provide us with the following information to proceed futher!!!',fg='black',bg='SkyBlue',font=labelfont1)
    canvas12.create_window(550, 22 , window=c1)

    canvas2 = Canvas(r, width = 500, height = 270,bg="skyblue")
    canvas2.pack()
    lfont=('aerial',10,'bold')
    
    d=Label(r,text='Your Monthly Income',font=lfont,bg="deepskyblue2")
    canvas2.create_window(150, 70, window=d)
    
    e=Label(r,text='Your Ideal Monthly Budget',font=lfont,bg="deepskyblue2")
    canvas2.create_window(150, 110, window=e)
    
    e1=Entry(r,bg='white',font=lfont,highlightcolor="red")
    canvas2.create_window(350,70, window=e1)
    
    e2=Entry(r,bg='white',font=lfont,highlightcolor="red")
    canvas2.create_window(350,110, window=e2)
    
    button=Button(r,text='CONTINUE',activeforeground='BLUE',command=lambda:conti(r),width=10,height=2,bg="deepskyblue3",fg="white")
    canvas2.create_window(215,190, window=button)
        


def signup(r):
    def signup1(r):
        count=0
        name1=e1.get()
        name2=e2.get();
        pro=e3.get();
        eid=e4.get();
        cno=e5.get();
        pas=e6.get();
        print(cno.isdigit())
        if(len(cno)>10 or cno.isdigit()==False):
            count+=1
            print("a")
        if(len(pas)>9):
            count+=1
            print("b")
        if(eid.find("@gmail.com")!=-1 or eid.find("@yahoo.com")!=-1 ):
            count+=1
            print("c")
            
        if(name1=="" or name2=="" or eid==""):
            messagebox.showinfo("Error","Please fill all info")
        
        elif(count!=1):
            messagebox.showinfo("Error","Please enter valid datas")
            print(count)
        elif(count==1):
            con = connector.connect(port="3308",user="root",password="",database="expencemanager")
            custor=con.cursor()
            
            query="select * from userinfo where email='"+e4.get()+"'"
            custor.execute(query)
            a=custor.fetchall()
            print(a)
            print(a==[])
            if(a==[]):
               con = connector.connect(port="3308",user="root",password="",database="expencemanager")
               custor=con.cursor()
               
               custor.execute("insert into userinfo values('"+name1+"','"+name2+"','"+pro+"','"+eid+"','"+cno+"','"+pas+"')")
               custor.execute("commit")
               messagebox.showinfo("SUCCESS","YOU HAVE REGISTERED!!!:).Just click continue!!!")
               custor.execute("select * from userinfo where email='"+eid+"'")
               global info
               info=custor.fetchall()
               print(info[0][3])
               
               con.close();
               """canvas3 = Canvas(r, width = 500, height = 50,bg="SkyBlue")
               canvas3.pack()"""
               button=Button(r,text='Continue',activeforeground='BLUE',command=lambda:budget1(r),width=10,height=2,bg="deepskyblue3",fg="white")
               canvas2.create_window(250,350, window=button)
            else:
               messagebox.showinfo("Error","Account already exists:(")
            e1.delete(0,'end')
            e2.delete(0,'end')
            e3.delete(0,'end')
            e4.delete(0,'end')
            e5.delete(0,'end')
            e6.delete(0,'end')
            
    r.destroy()
    r=Toplevel()
    r.title("₹ MY WALLET ₹")
    r.geometry("1100x700")
    r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
    canvas = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")
    canvas.pack()

    r.config(bg='white')
    labelfont=('times',40,'italic')
    a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)
    canvas.create_window(550, 50, window=a)
    icon = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
    p=Label(r,image=icon,bg="deepskyblue3")
    canvas.create_window(100, 50, window=p) 

    canvas1 = Canvas(r, width = 4000, height = 60,bg="SkyBlue3")
    canvas1.pack()
    labelfont1=('times',25,'italic')
    b=Label(r,text='$ Lets manage your money together $',fg='firebrick',bg='SkyBlue3',font=labelfont1)
    canvas1.create_window(550, 30, window=b)
    z=Button(r,text="<<Back",command=lambda:home1(r),bg="deepskyblue3",fg="white")
    canvas1.create_window(40,30, window=z)

    
    canvas11 = Canvas(r, width = 500, height = 70,bg="SkyBlue2")
    canvas11.pack()
    labelfont2=('times',20,'italic')
    c=Label(r,text='SIGN UP',fg='black',bg='SkyBlue2',font=labelfont2)
    canvas11.create_window(250, 40 , window=c)
    
    canvas12 = Canvas(r, width = 500, height = 50,bg="SkyBlue")
    canvas12.pack()
    labelfont3=('times',20,'italic')
    c1=Label(r,text='WELCOME!!!',fg='black',bg='SkyBlue',font=labelfont3)
    canvas12.create_window(250, 25 , window=c1)
    
    canvas2 = Canvas(r, width = 500, height = 400,bg="skyblue")
    canvas2.pack()
    lfont=('aerial',10,'bold')

    d=Label(r,text='First name',font=lfont,bg="deepskyblue2")
    canvas2.create_window(150, 70, window=d)

    e=Label(r,text='Last name',font=lfont,bg='deepskyblue2')
    canvas2.create_window(150, 110, window=e)

    f=Label(r,text='Profession',font=lfont,bg='deepskyblue2')
    canvas2.create_window(150, 150, window=f)

    g=Label(r,text='Emailid',font=lfont,bg='deepskyblue2')
    canvas2.create_window(150, 190, window=g)
    
    h=Label(r,text='Contactno',font=lfont,bg='deepskyblue2')
    canvas2.create_window(150, 230, window=h)
    
    i=Label(r,text='Password',font=lfont,bg='deepskyblue2')
    canvas2.create_window(150, 270, window=i)
    
    j=Label(r,text='(only 9 character allowed)',font=lfont,bg="white",fg="red")
    canvas2.create_window(250, 310, window=j)

    e1=Entry(r,bg='white',font=lfont,highlightcolor="red")
    canvas2.create_window(300,70, window=e1)
    
    e2=Entry(r,bg='white',font=lfont)
    canvas2.create_window(300,110, window=e2)
    
    e3=Entry(r,bg='white',font=lfont)
    canvas2.create_window(300,150, window=e3)
    
    e4=Entry(r,bg='white',font=lfont)
    canvas2.create_window(300,190, window=e4)
    
    e5=Entry(r,bg='white',font=lfont)
    canvas2.create_window(300,230, window=e5)

    e6=Entry(r,bg='white',font=lfont,show="*")
    canvas2.create_window(300,270, window=e6)

    button=Button(r,text='SIGN UP',activeforeground='BLUE',command=lambda:signup1(r),width=10,height=2,bg="deepskyblue3",fg="white")
    canvas2.create_window(250,350, window=button)

    r.mainloop()

def login(r):
    def login1(r):
        name=e1.get()
        email=e2.get()
        pas=e3.get()
        dte=datetime.date(datetime.now())
        d=str(dte).split('-')
        query="select * from userinfo where email='"+email+"'and fname='"+name+"'and password='"+pas+"'"
        custor.execute(query)
        a=custor.fetchall()
        print(a)
        if(a!=[]):
            custor.execute("select * from userinfo where email='"+email+"'")
            global info,budget
            info=custor.fetchall()
            custor.execute("select * from budget where email='"+email+"'")
            budget=custor.fetchall()
            print(budget)
            m=str(budget[0][3]).split('-')
            print(m[1],d[1])
            if m[1]==d[1]:
                gui=homepg(r)
            else:
                budget1(r)
        
        else:
            messagebox.showinfo("Error","Please input valid information")  
    r.destroy()        
    r = Toplevel()
    r.title('₹ MY WALLET ₹')
    r.geometry("1100x700")
    r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
    
    canvas = Canvas(r, width = 4000, height = 90,bg="deepskyblue3")
    canvas.pack()
    
    r.config(bg='white')
    labelfont=('times',40,'italic')
    a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)
    canvas.create_window(550, 50, window=a)
    icon= PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
    i=Label(r,image=icon,bg="deepskyblue3")
    canvas.create_window(100, 50, window=i)
    

    canvas1 = Canvas(r, width = 4000, height = 60,bg="SkyBlue3")
    canvas1.pack()
    labelfont=('times',25,'italic')
    b=Label(r,text='$ Lets manage your money together $',fg='firebrick',bg='SkyBlue3',font=labelfont)
    canvas1.create_window(550, 30, window=b)
    z=Button(r,text="<<Back",command=lambda:home1(r),bg="deepskyblue3",fg="white")
    canvas1.create_window(40,30, window=z)

    canvas11 = Canvas(r, width = 500, height = 70,bg="SkyBlue2")
    canvas11.pack()
    labelfont1=('times',25,'italic')
    c=Label(r,text='LOG IN',fg='black',bg='SkyBlue2',font=labelfont1)
    canvas11.create_window(250, 40 , window=c)

    canvas12 = Canvas(r, width = 500, height = 50,bg="SkyBlue")
    canvas12.pack()
    labelfont1=('times',20,'italic')
    c1=Label(r,text='WELCOME BACK!!!',fg='black',bg='SkyBlue',font=labelfont1)
    canvas12.create_window(250, 22 , window=c1)

    canvas2 = Canvas(r, width = 500, height = 270,bg="skyblue")
    canvas2.pack()
    lfont=('aerial',10,'bold')
    
    d=Label(r,text='User name',font=lfont,bg="deepskyblue2")
    canvas2.create_window(150, 70, window=d)
    
    e=Label(r,text='Email',font=lfont,bg="deepskyblue2")
    canvas2.create_window(150, 110, window=e)
    
    f=Label(r,text='Password',font=lfont,bg="deepskyblue2")
    canvas2.create_window(150, 150, window=f)
    
    e1=Entry(r,bg='white',font=lfont,highlightcolor="red")
    canvas2.create_window(300,70, window=e1)
    
    e2=Entry(r,bg='white',font=lfont,highlightcolor="red")
    canvas2.create_window(300,110, window=e2)
    
    e3=Entry(r,bg='white',font=lfont,show="*",highlightcolor="red")
    canvas2.create_window(300,150, window=e3)    
    
    button=Button(r,text='LOGIN',activeforeground='BLUE',command=lambda:login1(r),width=10,height=2,bg="deepskyblue3",fg="white")
    canvas2.create_window(300,190, window=button)

    r.mainloop()


def home1(r):
    r.destroy()
    r=Toplevel()
    r.title('₹ MY WALLET ₹')
    r.geometry("1100x700")
    r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
    r.config(bg='white')
    labelfont=('times new roman',40,'italic')

    canvas1 = Canvas(r, width = 4000, height = 90,bg="VioletRed3")
    canvas1.pack()

    a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='VioletRed3',font=labelfont)
    canvas1.create_window(550,50,window=a)
    icon = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\icon.png")
    i=Label(r,image=icon,bg="violetred3")
    canvas1.create_window(100, 50, window=i) 

    canvas2 = Canvas(r, width = 4000, height = 60,bg="PaleVioletRed")
    canvas2.pack()
    lfont=('aerial',20,'italic')

    b=Label(r,text='$ Lets manage your money together $',fg='white',bg='PaleVioletRed',font=lfont)
    canvas2.create_window(550,30,window=b)
            
    Image_ = Image.open("C:\\Mhanjhupro2\\mhanjhu pro\\cash.png")
    ImageForTK = ImageTk.PhotoImage(Image_)

    ImageCanvas = Canvas(r, width = Image_.size[0], height = Image_.size[1])           
    ImageCanvas.pack()
    ImageCanvas.create_image(0, 0, anchor = NW, image = ImageForTK)


    canvas3 = Canvas(r, width = 445, height =60,bg="PaleVioletRed")
    canvas3.pack()
    lfont=('aerial',10,'bold')

    button1=Button(r,text='SIGN UP',command=lambda:signup(r),activeforeground='BLUE',width=10,height=2,fg='white',bg="VioletRed3")
    canvas3.create_window(125,30,window=button1)

    button2=Button(r,text='LOG IN',command=lambda:login(r),activeforeground='BLUE',width=10,height=2,fg='white',bg="VioletRed3")
    canvas3.create_window(325,30,window=button2)

    r.mainloop()
if cou==0:
    home1(r)
    r.mainloop()
else:
    r.destroy()













