from tkinter import *
root = Tk()
lst=['cake','bread','cream']
for a in lst:
    l = Label(root, text =a)
    l.pack()
root.mainloop() 
