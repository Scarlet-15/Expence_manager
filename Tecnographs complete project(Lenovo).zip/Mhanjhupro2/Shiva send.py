from tkinter import *
from PIL import ImageTk,Image
from mysql import connector 
from tkinter import messagebox
from datetime import datetime
from tkinter import filedialog
from functools import partial
from tabulate import tabulate
con = connector.connect(port="3308",user="root",password="",database="expencemanager")
custor=con.cursor()

r=Tk()



def expinfo(r,a):
    infor=a
    print(infor)
    r.destroy()
    cursor=con.cursor()
    cursor.execute("use expencemanager")
    global photo,value,info
    value=""
    r =Toplevel()
    cudate=StringVar()
    
    curdate=""
    r.geometry("1100x700")
    r.title('₹ MY WALLET ₹')
    r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
    r.config(bg='white')
    urdate=str(datetime.date(datetime.now()))
    rdate=urdate.split('-')
    for a in range(len(rdate)-1,-1,-1):
        curdate+=(rdate[a]+".")
    print(curdate)
    curdate=curdate[:len(curdate)-1]
    canvas1 = Canvas(r, width = 4000, height = 90,bg="deepskyblue3")
    canvas1.pack()
        
    labelfont=('times',30,'italic')
        
    a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)
    canvas1.create_window(550, 50, window=a)

    canvas2 = Canvas(r, width = 4000, height = 40,bg="deepskyblue2")
    canvas2.pack()
    labelfont1=('aerial',15,'italic')
    b=Label(r,text='$-Lets manage your money together-$',fg='white',bg='deepskyblue2',font=labelfont1)
    canvas2.create_window(550,25, window=b)   
    canvas1 = Canvas(r, width = 4000, height = 30,bg="deepskyblue")
    canvas1.pack()
    if infor==1:    
        c=Label(r,text='ADD EXPENSES',fg='white',bg='deepskyblue',font=('bold'))
        canvas1.create_window(550,15, window=c)
        d=Button(r,text="<<Back",bg="deepskyblue3",command=lambda:homepg(r),fg="white")
        canvas1.create_window(30,17, window=d)
    else:
        c=Label(r,text='EDIT',fg='white',bg='deepskyblue',font=('bold'))
        canvas1.create_window(550,15, window=c)
        d=Button(r,text="<<Back",bg="deepskyblue3",command=lambda:alltrans1(r),fg="white")
        canvas1.create_window(30,17, window=d)
    
    
        
    canvas2 = Canvas(r, width = 500, height = 600,bg="skyblue")
    canvas2.pack()
        
    lfont=('aerial',10,'bold')
    f=Label(r,text='PAID FOR',font=lfont)
    canvas2.create_window(77,50, window=f)
    e=Label(r,text='AMOUNT',font=lfont)
    canvas2.create_window(74,100, window=e)

    g=Label(r,text='DATE(DD.MM.YYYY)',font=lfont)
    canvas2.create_window(107,150, window=g)
    h=Label(r,text='DESCRIPTION (optional)',font=lfont)
    canvas2.create_window(120,200, window=h)
    i=Label(r,text='MODE OF TRANSACTION',font=lfont)
    canvas2.create_window(118,300, window=i)
    j=Label(r,text='CATOGORY',font=lfont)
    canvas2.create_window(75,350, window=j)

    def inform(r,infor):
        global photo
        def info1(r,infor):
            r.destroy()
            global photo
            r = Toplevel()
            r.geometry("1100x700")
            r.title(' MY WALLET ')
            r.config(bg='white')
            canvas1 = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            labelfont=('times',30,'italic')
                
            a=Label(r,text=' MY WALLET ',fg='white',bg='deepskyblue3',font=labelfont)    
            canvas1.create_window(550, 50, window=a)                                         #adding the heading label to the canvas
            canvas1 = Canvas(r, width = 4000, height = 30,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            b=Label(r,text='Lets manage your money together',fg='white',bg='deepskyblue3',font=('italic'))
            canvas1.create_window(550,15, window=b)                                          #adding the heading label to the canvas
            d=Button(r,text="<<Back",bg="deepskyblue3",fg="white",command=lambda:expinfo(r,infor))
            canvas1.create_window(30,17, window=d)    
            canvas1 = Canvas(r, width = 4000, height = 800,bg="white")                 #creation of the subheading canvas
            canvas1.pack()
            labelfont=('times',30,'italic')
            a=Label(r,text='INFO',fg='white',bg='deepskyblue3',font=labelfont)
            canvas1.create_window(550,40, window=a)
            b=Label(r,text='What Is Considered to Be a Living Expense?',bg="white",font=labelfont)
            canvas1.create_window(600,100, window=b)

            labelfont=('times',13,'bold','underline')
            c=Label(r,text='Housing:\n Whether you rent or own, there are regular expenses, including some you\n may not be aware of.',fg='black',bg='lightgrey',font=labelfont)
            canvas1.create_window(750,150, window=c)
            lfont=('times',10,'italic')
            d=Label(r,text='•Mortgage payment or monthly rent \n •Utilities \n •Insurance \n •Property tax',fg='black',bg='white',font=lfont)
            canvas1.create_window(650,220, window=d)
            lablefont=('times',13,'bold','underline')
            e=Label(r,text='Food and grocery: \n Besides your daily meals, consider other living necessities.',fg='black',bg='lightgrey',font=lablefont)
            canvas1.create_window(700,290, window=e)
            lfont=('times',10,'italic')
            f=Label(r,text='•Food and beverages \n •Personal care items \n •Cleaning supplies',fg='black',bg='white',font=lfont)
            canvas1.create_window(700,350, window=f)
            lablefont=('times',13,'bold','underline')
            g=Label(r,text='Clothing:\n From your work clothes to pajamas, ensure you account for everyone in your family.',fg='black',bg='lightgrey',font=lablefont)
            canvas1.create_window(400,410, window=g)
            lfont=('times',10,'italic')
            h=Label(r,text='•Daily clothing \n •Formal wear \n •Boots, shoes, and coats',fg='black',bg='white',font=lfont)
            canvas1.create_window(390,470, window=h)


            button=Button(r,text='[1]→',activeforeground='blue',width=5,height=1,bg='deepskyblue3',fg="white",command=lambda:info2(r,infor))
            canvas1.create_window(550,550, window=button)

            photo = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\catogory.png")
            canvas1.create_image(200,250, image=photo)

        def info2(r,infor):
            r.destroy()
            global photo
            r = Toplevel()
            r.geometry("1100x700")
            r.title(' MY WALLET ')
            r.config(bg='white')
            canvas1 = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            labelfont=('times',30,'italic')
                
            a=Label(r,text=' MY WALLET ',fg='white',bg='deepskyblue3',font=labelfont)    
            canvas1.create_window(550, 50, window=a)                                         #adding the heading label to the canvas
            canvas1 = Canvas(r, width = 4000, height = 30,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            b=Label(r,text='Lets manage your money together',fg='white',bg='deepskyblue3',font=('italic'))
            canvas1.create_window(550,15, window=b)                                          #adding the heading label to the canvas
                
            canvas1 = Canvas(r, width = 4000, height = 800,bg="white")                 #creation of the subheading canvas
            canvas1.pack()
            labelfont=('times',30,'italic')
            a=Label(r,text='INFO',fg='white',bg='deepskyblue3',font=labelfont)
            canvas1.create_window(550,40, window=a)
            b=Label(r,text='What Is Considered to Be a Living Expense?',bg="white",font=labelfont)
            canvas1.create_window(600,100, window=b)


            labelfont=('times',13,'bold','underline')
            c=Label(r,text='Healthcare:\n Remember to include expenses for your primary doctor, dentist, and other specialists',fg='black',bg='lightgrey',font=labelfont)
            canvas1.create_window(750,150, window=c)
            lfont=('times',10,'italic')
            d=Label(r,text='•Insurance premiums \n •Office copays \n •Pharmacy copays \n •Over-the-counter item',fg='black',bg='white',font=lfont)
            canvas1.create_window(650,220, window=d)
            lablefont=('times',13,'bold','underline')
            e=Label(r,text='Transportation:\n Depending on whether you take the bus or drive a car, add up your regular\n transportation costs.',fg='black',bg='lightgrey',font=lablefont)
            canvas1.create_window(710,290, window=e)
            lfont=('times',10,'italic')
            f=Label(r,text='•Car payment &•Car insurance \n •Gas \n •Public transportation tickets & Taxi costs\n •Parking fees & toll tax',fg='black',bg='white',font=lfont)
            canvas1.create_window(650,370, window=f)
            lablefont=('times',13,'bold','underline')
            g=Label(r,text='Miscellaneous: \nSome living expenses don’t fit a specific category, but still need to be in your budget.',fg='black',bg='lightgrey',font=lablefont)
            canvas1.create_window(400,410, window=g)
            lfont=('times',10,'italic')
            h=Label(r,text='Cell phone bill\n •Internet\n •Baby or child necessities',fg='black',bg='white',font=lfont)
            canvas1.create_window(390,470, window=h)

            button=Button(r,text='←[1]',activeforeground='blue',width=5,height=1,bg='deepskyblue3',fg="white",command=lambda:info1(r,infor))
            canvas1.create_window(500,530, window=button)
            button=Button(r,text='[2]→',activeforeground='blue',width=5,height=1,bg='deepskyblue3',fg="white",command=lambda:info3(r,infor))
            canvas1.create_window(550,530, window=button)

            photo = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\catogory.png")
            canvas1.create_image(200,250, image=photo)
        def info3(r,infor):
            r.destroy()
            global photo
            r = Toplevel()
            r.geometry("1100x700")
            r.title(' MY WALLET ')
            r.config(bg='white')
            canvas1 = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            labelfont=('times',30,'italic')
                
            a=Label(r,text=' MY WALLET ',fg='white',bg='deepskyblue3',font=labelfont)    
            canvas1.create_window(550, 50, window=a)                                         #adding the heading label to the canvas
            canvas1 = Canvas(r, width = 4000, height = 30,bg="deepskyblue3")               #creation of the heading canvas
            canvas1.pack()
            b=Label(r,text='Lets manage your money together',fg='white',bg='deepskyblue3',font=('italic'))
            canvas1.create_window(550,15, window=b)                                          #adding the heading label to the canvas
                
            canvas1 = Canvas(r, width = 4000, height = 800,bg="white")                 #creation of the subheading canvas
            canvas1.pack()
            labelfont=('times',30,'italic')
            a=Label(r,text='INFO',fg='white',bg='deepskyblue3',font=labelfont)
            canvas1.create_window(550,40, window=a)
            b=Label(r,text='What Is Considered to Be a Living Expense?',bg="white",font=labelfont)
            canvas1.create_window(600,100, window=b)


            labelfont=('times',13,'bold','underline')
            c=Label(r,text='Loan: \nWhen money is given to another party in exchange for repayment of the loan\n principal amount plus interest',fg='black',bg='lightgrey',font=labelfont)
            canvas1.create_window(750,150, window=c)
            lfont=('times',10,'italic')
            d=Label(r,text='•Gold loan \n •Housing loan \n •Education loan \n •Personal Loan',fg='black',bg='white',font=lfont)
            canvas1.create_window(650,220, window=d)
            lablefont=('times',13,'bold','underline')
            e=Label(r,text='Tax:\n A compulsory contribution to state revenue, levied by the government on\n workers income.',fg='black',bg='lightgrey',font=lablefont)
            canvas1.create_window(750,290, window=e)
            lfont=('times',10,'italic')
            f=Label(r,text='•Income tax \n •Property tax \n •Water tax \n • Health tax',fg='black',bg='white',font=lfont)
            canvas1.create_window(650,370, window=f)

            button=Button(r,text='←[2]',activeforeground='blue',width=5,height=1,fg='white',bg="deepskyblue3",command=lambda:info2(r,infor))
            canvas1.create_window(550,450, window=button)


            photo = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\catogory.png")
            canvas1.create_image(200,250, image=photo)
        info1(r,infor)
    font=("aerial",10,"italic")

    if infor==1:
        e1=Entry(r,bg='white',font=font)
        canvas2.create_window(300,100, window=e1)
        e2=Entry(r,bg='white',font=font)
        canvas2.create_window(300,50, window=e2)
        cudate.set(curdate)
        print(type(cudate))
        e3=Entry(r,bg='white',font=font,text=cudate)
        canvas2.create_window(300,150, window=e3)
        e4=Text(r,bg='white',font=font,height=5,width=20)
        canvas2.create_window(300,225, window=e4)
        e4.insert(END,"")
    else:
        pf=StringVar()
        amt=StringVar()
        date=StringVar()
        des=infor[3]
        dat=str(infor[2]).split("-")
        da=dat[2]+"."+dat[1]+"."+dat[0]
        pf.set(infor[1])
        amt.set(infor[0])
        date.set(da)
            
        e1=Entry(r,bg="white",font=font,text=amt)
        canvas2.create_window(300,100, window=e1)
        e2=Entry(r,bg='white',font=font,text=pf)
        canvas2.create_window(300,50, window=e2)
            
        e3=Entry(r,bg='white',font=font,text=date)
        canvas2.create_window(300,150, window=e3)
        e4=Text(r,bg='white',font=font,height=5,width=20)
        canvas2.create_window(300,225, window=e4)
        e4.insert(END,des)
        
    lb = Listbox(r, height =8, width =20,bg = "white",activestyle = 'dotbox',font =font, fg = "black")
    canvas2.create_window(300,400, window=lb)
    def CurSelet(evt):
        global value
        value=lb.get(lb.curselection())
                     
        
    cat=["Housing","Food and grocery","Clothing","Healthcare","Transportation","Loan","Tax","Miscellaneous"]
    for i in cat:
        lb.insert(END,i)
    lb.bind('<<ListboxSelect>>',CurSelet)
    k=Label(r,text='''(*Help us organise your
        expenses in a better way)''',bg="skyblue",fg="red",font=font)
    canvas2.create_window(100,390, window=k)
    photo = PhotoImage(file = r"C:\Mhanjhupro2\mhanjhu pro\info.png") 
    h=Button(r,image=photo,bg="white",command=lambda:inform(r,infor))
    canvas2.create_window(145,350, window=h)
    global w
    global fname
    fname=""

    w=IntVar()
    w.set(0)
    c1=Checkbutton(r, text = "Other means", variable = w, onvalue = 0,offvalue =1,bg='white',fg='black')
    canvas2.create_window(275,300, window=c1)
    c2=Checkbutton(r, text = "Cash in hand",variable = w,onvalue = 1,offvalue=0,bg='white',fg='bLack')
    canvas2.create_window(400,300, window=c2)
    def saveimg():
        global fname
        fname = filedialog.askopenfilename(title ='Select file')
        le=len(fname)
        if fname[(le-4):]==".jpg" or fname[(le-4):]==".jpeg" or fname[(le-4):]==".png":
            fname=fname
            messagebox.showinfo("SUCCESS","Upload successful!!!")
        else:
            messagebox.showwarning("ERROR","Please upload .jpg or .jpeg or.png file only")
        print(fname,"hi")


    def save(infor):
        if infor==1:
            MsgBox = messagebox.askquestion ('Save','Are you sure you want to save the given values?')
        else:
            MsgBox = messagebox.askquestion ('Save','Are you sure you want to Edit your values?')
        if MsgBox == 'yes':
            count=0
            
            global w,info,value
            global fname
            print(value)
            inf=info[0][3]
            if fname=="":
                fname="None"
            datef=""    
            n=' '
            amt=e1.get()
            uf=e2.get()
            f=e3.get()
            descr=""    
                
            l=e4.get("1.0", "end")
            l.rstrip("")
            for b in range(0,len(l),20):
                descr+=l[b:b+20]+'\n'
            print(len(descr),descr,"hi")
            if w.get()==0:
                mot='other means'
            else:
                mot='cash in hand'
            print(datef)       
            dmy=f.split('.')
            dmy.reverse()
            print(dmy)
            if (amt!="" and uf!="" and len(dmy)==3 and value!=""):
                count+=1
                print("d")
            if amt.isdigit():
                count+=1
                print("a")
            if uf.isalpha():
                count+=1
                print("b")
            if (f[0:2].isdigit())and(f[2]=='.')and(f[3:5].isdigit())and(f[5]=='.')and(f[6:].isdigit())and(len(f)==10):
                count+=1
                print("c")
                dd=int(dmy[2])
                mm=int(dmy[1])
                yy=int(dmy[0])
                if((mm < 1 or mm > 12)or(dd < 1 or dd > 31)):
                    messagebox.showwarning("ERROR"," ENTER VALID DATE1")
                    return 10
                else:
                    if mm == 1 or mm == 3 or mm == 5 or mm == 7 or mm == 8 or mm == 10 or mm == 12:
                        max_day_value = 31
                    elif mm == 4 or mm == 6 or mm == 9 or mm == 11:
                        max_day_value = 30
                    elif yy % 4 == 0 and yy % 100 != 0 or yy % 400 == 0:
                        max_day_value = 29
                    else:
                        max_day_value = 28
                    if dd > max_day_value:
                        messagebox.showwarning("ERROR"," ENTER VALID DATE")
                        return 
            else:
                print(count)
            for a in dmy:
                datef+=a
                
            if count==4:
                if infor!=1:
                    cursor.execute("delete from expence where AMOUNT=%s and USEDFOR=%s and DATE=%s and DESCRIPTION=%s and MODEOFTRANSACTION=%s and BILL=%s and \
CATOGORY=%s and email=%s",[infor[0],infor[1],infor[2],infor[3],infor[4],infor[5],infor[6],inf])
                    
                    cursor.execute("insert into expence values(%s,%s,%s,%s,%s,%s,%s,%s)",[amt,uf,datef,descr,mot,fname,value,inf])
                    messagebox.showinfo("Edit","Successfully edited data")
                    gui=alltrans1(r)
                else:
                    cursor.execute("insert into expence values(%s,%s,%s,%s,%s,%s,%s,%s)",[amt,uf,datef,descr,mot,fname,value,inf])
                    messagebox.showinfo("Save","Successfully inserted data")
                    e1.delete(0,'end')
                    e2.delete(0,'end')
                    e4.delete(1.0,'end')
            else:
                messagebox.showwarning("ERROR"," ENTER VALID VALUES")
    def delete():
        global info
        inf=info[0][3]
        MsgBox = messagebox.askquestion ('Delete','Are you sure you want to save delete this record?')
        if MsgBox=="yes":
            cursor.execute("delete from expence where AMOUNT=%s and USEDFOR=%s and DATE=%s and DESCRIPTION=%s and MODEOFTRANSACTION=%s and BILL=%s and \
CATOGORY=%s and email=%s",[infor[0],infor[1],infor[2],infor[3],infor[4],infor[5],infor[6],inf])
            messagebox.showinfo("Delete","This record has been deleted...!")
            gui=alltrans1(r)
            
        
    if infor==1:
        button1=Button(r,text='SAVE',command=lambda:save(infor),bg="deepskyblue3",fg="white",width=10,height=2)
        canvas2.create_window(350,500, window=button1)
        button2=Button(r,text='UPLOAD BILL(optional)',command=saveimg,width=20,bg="deepskyblue3",fg="white",height=2)
        canvas2.create_window(150,500, window=button2)
    
    else:
        button2=Button(r,text='UPLOAD BILL(optional)',command=saveimg,width=20,bg="deepskyblue3",fg="white",height=2)
        canvas2.create_window(150,500, window=button2)
        button1=Button(r,text='EDIT',bg="deepskyblue3",command=lambda:save(infor),fg="white",width=10,height=2)
        canvas2.create_window(400,500, window=button1)
        button3=Button(r,text='DELETE',bg="red",fg="white",command=delete,width=10,height=2)
        canvas2.create_window(285,500, window=button3)
    
        
    
              
   
def alltrans1(r):

    global info
    def alltrans(r):
            
        def button(r,canvas2,c,i,b,cat):
            print("hi1")
            a=Button(r,text="Edit"+" "+b[i][1],bg="green",fg="white",font=("aerial",10,"bold"),command=lambda:expinfo(r,b[i]+(cat,)))
            canvas2.create_window(1000,c, window=a)
       
            
        def click(a,r):
            global info
            custor.execute("select AMOUNT,USEDFOR,DATE,DESCRIPTION,MODEOFTRANSACTION,BILL from expence where \
                           CATOGORY=%s and email=%s order by DATE desc",[a[0],info[0][3]])

            cat=a[0]
            r.destroy()
            r =Toplevel()
            r.geometry("1100x700")
            canvas1 = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")
            canvas1.pack()
            r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
            r.title('₹ MY WALLET ₹')
            r.config(bg='white')
            labelfont=('times',30,'italic')
            lfont=('times',15,'italic')
            lafont=('times',20,'bold')
            a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)
            canvas1.create_window(550, 50, window=a)
            
            canvas2 = Canvas(r, width = 4000, height = 50,bg="deepskyblue2")
            canvas2.pack()
            lfont1=('times',20,'italic')
            b=Label(r,text='$-Lets manage your money together-$',fg='white',bg='deepskyblue2',font=lfont1)
            canvas2.create_window(550,25, window=b)
            canvas11 = Canvas(r, width = 4000, height = 50,bg="deepskyblue2")
            canvas11.pack()
            lfont2=('times',20,'italic')
            e=Label(r,text=cat,fg='white',bg='deepskyblue2',font=lfont2)
            canvas11.create_window(550,25, window=e)
            f=Button(r,text="<<Back",bg="deepskyblue3",command=lambda:alltrans(r),fg="white")
            canvas11.create_window(30,25, window=f)
            
            frame = Frame(r, width = 4000, height =1000,bg="blue")
            frame.pack()
            canvas2 = Canvas(frame, width = 4000, height =1000,scrollregion=(0,0,4500,3000),bg="ghost white")
            
            vbar=Scrollbar(frame,orient=VERTICAL)
            vbar.pack(side=RIGHT,fill=Y)
            vbar.config(command=canvas2.yview)
            canvas2.config(width=4000,height=1000)
            canvas2.config(yscrollcommand=vbar.set)
            canvas2.pack()

            b=custor.fetchall()
            d=[]
            c=((50*len(b))/2)-(len(b)*2)
            for i in range(len(b)):
                d.append(b[i][:len(b[i])-1])
                button(r,canvas2,c,i,b,cat)
                """if b[i][5]!="None":
                    button1(r,canvas2,c)"""
                c+=(b[i][3].count('\n')*17)
                
            print(b)
            headers=["AMOUNT","USED FOR","DATE","DESCRIPTION","MODE OF TRANSACTION"]
            table=tabulate(d,headers,tablefmt="grid",numalign="right",stralign="left")
            
            d=Label(r,text=table,font=("courier new",10),bg="GHOST white")
            canvas2.create_window(550,len(b)*50, window=d)
            
            

        global info
        print(info)
        r.destroy()
        r =Toplevel()
        r.geometry("1100x700")
        canvas1 = Canvas(r, width = 4000, height = 100,bg="deepskyblue3")
        canvas1.pack()
        r.iconbitmap(r'C:\Mhanjhupro2\mhanjhu pro\icon1.ico')
        r.title('₹ MY WALLET ₹')
        r.config(bg='white')
        labelfont=('times',30,'italic')
        lfont=('times',15,'italic')
        lafont=('times',20,'bold')
        a=Label(r,text='₹€ MY WALLET €₹',fg='white',bg='deepskyblue3',font=labelfont)
        canvas1.create_window(550, 50, window=a)
        sb = Scrollbar()  
        sb.pack(side = RIGHT, fill = Y)
        canvas2 = Canvas(r, width = 4000, height = 50,bg="deepskyblue2")
        canvas2.pack()
        lfont1=('times',20,'italic')
        b=Label(r,text='$-Lets manage your money together-$',fg='white',bg='deepskyblue2',font=lfont1)
        canvas2.create_window(550,25, window=b)
        canvas11 = Canvas(r, width = 4000, height = 50,bg="deepskyblue2")
        canvas11.pack()
        lfont2=('times',20,'italic')
        e=Label(r,text='ALL TRANSACTION',fg='white',bg='deepskyblue2',font=lfont2)
        canvas11.create_window(550,25, window=e)
        f=Button(r,text="<<Back",bg="deepskyblue3",command=lambda:homepg(r),fg="white")
        canvas11.create_window(30,25, window=f)


        
        custor.execute("select CATOGORY,sum(AMOUNT) from expence where email=%s group by CATOGORY ",[info[0][3]])
        a=custor.fetchall()
        print(b)
        
        c=1
        canvas2 = Canvas(r, width = 500, height =65,bg="ghost white")
        canvas2.pack()
        d=Label(r,text="S.NO",font=lfont,bg="GHOST white")
        canvas2.create_window(50,35, window=d)
        e=Label(r,text="CATOGORY",font=lfont,bg="ghostwhite")
        canvas2.create_window(150,35, window=e)
        f=Label(r,text="AMOUNT",font=lfont,bg="ghostwhite")
        canvas2.create_window(275,35, window=f)
        for b in a:
            canvas2 = Canvas(r, width = 500, height =65,bg="ghost white")
            canvas2.pack()
            d=Label(r,text=str(c)+'.',font=lfont,bg="white")
            canvas2.create_window(50,35, window=d)
            e=Label(r,text=b[0],font=lfont,bg="white")
            canvas2.create_window(150,35, window=e)
            f=Label(r,text=b[1],font=lfont,bg="white")
            canvas2.create_window(270,35, window=f)
            g=Button(r,text="View",bg="green",fg="white",font=("aerial",10,"bold"),command=partial(click,b,r))
            
            canvas2.create_window(400,35, window=g)
            print(b)
            c+=1
       
        r.mainloop()
    alltrans(r)

